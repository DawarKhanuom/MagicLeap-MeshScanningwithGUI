# Meshing Sample App

This sample demonstrates how to setup meshing API.


## Prerequisites

Refer to https://developer-docs.magicleap.cloud/docs/guides/native/getting-started/native-getting-started

## Gui
 - None

## Running on device

```sh
adb install ./app/build/outputs/apk/ml2/debug/com.magicleap.capi.sample.meshing-debug.apk
adb shell am start -a android.intent.action.MAIN -n com.magicleap.capi.sample.meshing/android.app.NativeActivity
```

## Removing from device

```sh
adb uninstall com.magicleap.capi.sample.meshing
```

## What to Expect

 - Room around should be covered with triangles
 - The mesh should get better with each frame
 - You can change LOD by clicking Bumper button, there are 3 levels
