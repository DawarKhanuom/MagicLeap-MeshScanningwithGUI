// %BANNER_BEGIN%
// ---------------------------------------------------------------------
// %COPYRIGHT_BEGIN%
// Copyright (c) 2022 Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Software License Agreement,
// located here: https://www.magicleap.com/software-license-agreement-ml2
// Terms and conditions applicable to third-party materials accompanying
// this distribution may also be found in the top-level NOTICE file
// appearing herein.
// %COPYRIGHT_END%
// ---------------------------------------------------------------------
// %BANNER_END%

#define ALOG_TAG "com.magicleap.capi.sample.meshing"

#include "meshing_material.h"

#include <app_framework/application.h>
#include <app_framework/components/magicleap_mesh_component.h>
#include <app_framework/components/renderable_component.h>
#include <app_framework/convert.h>
#include <app_framework/gui.h>

#include <ml_head_tracking.h>
#include <ml_input.h>
#include <ml_meshing2.h>
#include <ml_perception.h>

// for using MLCoordinateFrameUID in std::unordered_map
namespace std {
template <>
struct hash<MLCoordinateFrameUID> {
  size_t operator()(const MLCoordinateFrameUID &id) const {
    std::size_t h1 = std::hash<uint64_t>{}(id.data[0]);
    std::size_t h2 = std::hash<uint64_t>{}(id.data[1]);
    return h1 ^ (h2 << 1);
  }
};
}  // namespace std

// for using MLCoordinateFrameUID in std::unordered_map
bool operator==(const MLCoordinateFrameUID &lhs, const MLCoordinateFrameUID &rhs) {
  return (lhs.data[0] == rhs.data[0]) && (lhs.data[1] == rhs.data[1]);
}

class MeshingApp : public ml::app_framework::Application {
public:
  MeshingApp(struct android_app *state)
      : ml::app_framework::Application(state, std::vector<std::string>{"com.magicleap.permission.SPATIAL_MAPPING"},
                                       USE_GUI),
        head_tracker_(ML_INVALID_HANDLE),
        meshing_client_(ML_INVALID_HANDLE),
        input_handle_(ML_INVALID_HANDLE),
        current_mesh_info_request_(ML_INVALID_HANDLE),
        current_mesh_request_(ML_INVALID_HANDLE),
        meshing_lod_(MLMeshingLOD_Medium) {
    request_extents_.center = {{{0.f, 0.f, 0.f}}};
    request_extents_.rotation = {{{0.f, 0.f, 0.f, 1.f}}};
    request_extents_.extents = {{{10.f, 10.f, 10.f}}};
  }

  void OnResume() override {
    if (ArePermissionsGranted()) {
      mesh_material_ = std::make_shared<MeshVisualizationMaterial>();
      mesh_material_->SetPolygonMode(GL_LINE);
      UNWRAP_MLRESULT(MLMeshingInitSettings(&meshing_settings_));
      meshing_settings_.fill_hole_length = 3.f;
      meshing_settings_.disconnected_component_area = 0.5f;
      meshing_settings_.flags = MLMeshingFlags_ComputeConfidence | MLMeshingFlags_RemoveMeshSkirt;
      UNWRAP_MLRESULT(MLMeshingCreateClient(&meshing_client_, &meshing_settings_));
      UNWRAP_MLRESULT(MLHeadTrackingCreate(&head_tracker_));
      UNWRAP_MLRESULT(MLHeadTrackingGetStaticData(head_tracker_, &head_static_data_));
      UNWRAP_MLRESULT(MLInputCreate(&input_handle_));
      UNWRAP_MLRESULT(SetupControllerInput());
    }
  }

  void OnPause() override {
    CleanupControllerInput();
    if (MLHandleIsValid(current_mesh_info_request_)) {
      MLMeshingFreeResource(meshing_client_, &current_mesh_info_request_);
      current_mesh_info_request_ = ML_INVALID_HANDLE;
    }

    if (MLHandleIsValid(current_mesh_request_)) {
      MLMeshingFreeResource(meshing_client_, &current_mesh_request_);
      current_mesh_request_ = ML_INVALID_HANDLE;
    }

    if (MLHandleIsValid(input_handle_)) {
      UNWRAP_MLRESULT(MLInputDestroy(input_handle_));
      input_handle_ = ML_INVALID_HANDLE;
    }

    if (MLHandleIsValid(meshing_client_)) {
      UNWRAP_MLRESULT(MLMeshingDestroyClient(meshing_client_));
      meshing_client_ = ML_INVALID_HANDLE;
    }

    if (MLHandleIsValid(head_tracker_)) {
      UNWRAP_MLRESULT(MLHeadTrackingDestroy(head_tracker_));
      head_tracker_ = ML_INVALID_HANDLE;
    }

    mesh_block_nodes_.clear();
    block_requests_.clear();
    mesh_material_.reset();
  }

  void OnUpdate(float) override {
    RecenterExtentsOnHead();

    if (!MLHandleIsValid(current_mesh_info_request_)) {
      RequestMeshInfo();
    } else {
      ReceiveMeshInfoRequest();
    }

    if (!MLHandleIsValid(current_mesh_request_)) {
      if (!block_requests_.empty()) {
        RequestMesh();
      }
    } else {
      ReceiveMeshRequest();
    }
  };

private:
  void CleanupControllerInput() {
    if (MLHandleIsValid(input_handle_)) {
      UNWRAP_MLRESULT(MLInputSetControllerCallbacksEx(input_handle_, nullptr, nullptr));
    }
  }

  MLResult SetupControllerInput() {
    MLInputControllerCallbacksEx callbacks;
    MLInputControllerCallbacksExInit(&callbacks);

    callbacks.on_button_click = [](uint8_t controller_id, MLInputControllerButton button, void *data) {
      auto thiz = static_cast<MeshingApp *>(data);
      if (button == MLInputControllerButton_Bumper) {
        thiz->meshing_lod_ = thiz->GetNextLod();
      }
    };
    return MLInputSetControllerCallbacksEx(input_handle_, &callbacks, (void *)this);
  }

  const MLMeshingLOD GetNextLod() const {
    switch (meshing_lod_) {
      case MLMeshingLOD_Minimum: return MLMeshingLOD_Medium;
      case MLMeshingLOD_Medium: return MLMeshingLOD_Maximum;
      case MLMeshingLOD_Maximum: [[fallthrough]];
      default: return MLMeshingLOD_Minimum;
    }
  }

  void RecenterExtentsOnHead() {
    MLTransform head_transform = {};
    MLSnapshot *snapshot = nullptr;
    UNWRAP_MLRESULT(MLPerceptionGetSnapshot(&snapshot));
    UNWRAP_MLRESULT(MLSnapshotGetTransform(snapshot, &head_static_data_.coord_frame_head, &head_transform));
    UNWRAP_MLRESULT(MLPerceptionReleaseSnapshot(snapshot));
    request_extents_.center = head_transform.position;
  }

  void RequestMeshInfo() {
    ALOGV("MeshInfoRequest REQUESTING!");
    UNWRAP_MLRESULT(MLMeshingRequestMeshInfo(meshing_client_, &request_extents_, &current_mesh_info_request_));
  }

  void ReceiveMeshInfoRequest() {
    MLMeshingMeshInfo mesh_info = {};
    const MLResult result = MLMeshingGetMeshInfoResult(meshing_client_, current_mesh_info_request_, &mesh_info);
    switch (result) {
      case MLResult_Ok:
        UpdateBlockRequests(mesh_info);
        MLMeshingFreeResource(meshing_client_, &current_mesh_info_request_);
        current_mesh_info_request_ = ML_INVALID_HANDLE;
        return;
      case MLResult_Pending: ALOGV("MeshInfoRequest PENDING!"); return;
      default: UNWRAP_MLRESULT(result); current_mesh_info_request_ = ML_INVALID_HANDLE;
    }
  }

  void ReceiveMeshRequest() {
    MLMeshingMesh mesh = {};
    const MLResult result = MLMeshingGetMeshResult(meshing_client_, current_mesh_request_, &mesh);
    switch (result) {
      case MLResult_Ok:
        UpdateBlocks(mesh);
        MLMeshingFreeResource(meshing_client_, &current_mesh_request_);
        current_mesh_request_ = ML_INVALID_HANDLE;
        return;
      case MLResult_Pending: ALOGV("MeshRequest PENDING!"); return;
      default: UNWRAP_MLRESULT(result); current_mesh_request_ = ML_INVALID_HANDLE;
    }
  }

  void RequestMesh() {
    ALOGV("MeshRequest REQUESTING!");
    MLMeshingMeshRequest mesh_request = {};
    mesh_request.request_count = static_cast<int>(block_requests_.size());
    mesh_request.data = block_requests_.data();
    UNWRAP_MLRESULT(MLMeshingRequestMesh(meshing_client_, &mesh_request, &current_mesh_request_));
  }

  std::shared_ptr<ml::app_framework::Node> CreateMeshBlockNode() {
    auto node = std::make_shared<ml::app_framework::Node>();
    auto mesh_comp = std::make_shared<ml::app_framework::MagicLeapMeshComponent>();
    auto renderable = std::make_shared<ml::app_framework::RenderableComponent>(mesh_comp->GetMesh(), mesh_material_);
    node->AddComponent(renderable);
    node->AddComponent(mesh_comp);
    GetRoot()->AddChild(node);
    return node;
  }

  void UpdateBlockRequests(const MLMeshingMeshInfo &mesh_info) {
    block_requests_.clear();
    for (size_t i = 0; i < mesh_info.data_count; ++i) {
      const auto &mesh_data = mesh_info.data[i];
      MLMeshingBlockRequest request = {mesh_data.id, meshing_lod_};
      switch (mesh_data.state) {
        case MLMeshingMeshState_New: {
          block_requests_.push_back(request);
          auto new_block = CreateMeshBlockNode();
          const auto insert_result = mesh_block_nodes_.insert(std::make_pair(mesh_data.id, new_block));
          if (!insert_result.second) {
            ALOGV("MLMeshingMeshInfo state New: block already exists: %s",
                  ml::app_framework::to_string(mesh_data.id).c_str());
          }
          break;
        }
        case MLMeshingMeshState_Updated: {
          block_requests_.push_back(request);
          if (!mesh_block_nodes_.count(mesh_data.id)) {
            ALOGE("MLMeshingMeshInfo state Updated: nonexistant block %s",
                  ml::app_framework::to_string(mesh_data.id).c_str());
          }
          break;
        }
        case MLMeshingMeshState_Deleted: {
          auto to_remove = mesh_block_nodes_.find(mesh_data.id);
          if (to_remove != mesh_block_nodes_.end()) {
            GetRoot()->RemoveChild(to_remove->second);
            mesh_block_nodes_.erase(to_remove);
          }
          break;
        }
        case MLMeshingMeshState_Unchanged: {
          if (!mesh_block_nodes_.count(mesh_data.id)) {
            ALOGE("MLMeshingMeshInfo state Unchanged: nonexistant block %s",
                  ml::app_framework::to_string(mesh_data.id).c_str());
          }
          break;
        }
        default: break;
      }
    }
  }

  void UpdateBlocks(const MLMeshingMesh &mesh) {
    for (size_t i = 0; i < mesh.data_count; ++i) {
      const auto &mesh_data = mesh.data[i];
      if (!mesh_block_nodes_.count(mesh_data.id)) {
        ALOGE("MLMeshingMesh tried to update nonexistant block %s", ml::app_framework::to_string(mesh_data.id).c_str());
        continue;
      }
      auto mesh_component = mesh_block_nodes_[mesh_data.id]->GetComponent<ml::app_framework::MagicLeapMeshComponent>();
      mesh_component->UpdateMeshWithConfidence(reinterpret_cast<glm::vec3 *>(mesh_data.vertex),
                                               reinterpret_cast<glm::vec3 *>(mesh_data.normal), mesh_data.confidence,
                                               mesh_data.vertex_count, mesh_data.index, mesh_data.index_count);
    }
  }

  MLHeadTrackingStaticData head_static_data_;
  MLHandle head_tracker_, meshing_client_, input_handle_;
  MLHandle current_mesh_info_request_, current_mesh_request_;

  MLMeshingSettings meshing_settings_;
  MLMeshingExtents request_extents_;
  MLMeshingLOD meshing_lod_;
  std::vector<MLMeshingBlockRequest> block_requests_;
  std::unordered_map<MLCoordinateFrameUID, std::shared_ptr<ml::app_framework::Node>> mesh_block_nodes_;
  std::shared_ptr<MeshVisualizationMaterial> mesh_material_;
};

void android_main(struct android_app *state) {
  MeshingApp app(state);
  app.RunApp();
}
